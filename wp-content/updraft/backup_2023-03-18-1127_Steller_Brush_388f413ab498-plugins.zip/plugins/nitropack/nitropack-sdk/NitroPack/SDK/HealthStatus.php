<?php
namespace NitroPack\SDK;

class HealthStatus {
    const UNDER_THE_WEATHER  = "UNDER THE WEATHER";
    const HEALTHY = "HEALTHY";
    const SICK  = "SICK";
}
